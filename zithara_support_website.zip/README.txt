# Zithara AI Customer Support Website

This is a simple static website for Zithara's AI-based customer support.

## Features
- AI Chatbot UI (frontend only)
- FAQ Section
- Contact Form
- Responsive design

## How to Use
Just open `index.html` in your browser or upload the files to any web host (e.g., GitHub Pages, Netlify, Vercel).

## Customization
You can replace the placeholder logo and update colors or content as needed.

Enjoy!
